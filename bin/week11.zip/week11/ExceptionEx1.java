package week11;

public class ExceptionEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String data=null;
		
		System.out.println(data.toString());
	}

}
