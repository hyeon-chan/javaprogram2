package week11;

public class ExceptionEx3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String data1 = args[0];
		String data2 = args[1];
		
		System.out.println("args[0]: " + data1);
		System.out.println("args[1]: " + data2);
	}

}
