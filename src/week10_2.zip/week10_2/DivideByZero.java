package week10_2;

public class DivideByZero {
    public static void main(String[] args) {
        int result = 10 / 0;
        System.out.println("나눗셈 결과: " + result);
    }
}
