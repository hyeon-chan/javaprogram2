package week5;

public interface DataExInter {
	void hallymInput();
	void hallymSum();
	void hallymAvg();
	void hallymGrade();
	void hallymPrint();
}
